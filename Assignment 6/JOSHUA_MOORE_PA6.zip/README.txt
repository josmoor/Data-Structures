- The program will handle upper and lowercase words; the program converts all words to lowercase and will be displayed as such.
- If the program finds a match, then the set of words containing the first TWO letters of the word are displaye with their corresponding time.
- If the word given does not have any words that start with the same letter (ie. You put in 'a', but no words start with 'a'), then the program will show an error (didn't code for error, but this means empty set).

INSTRUCTIONS:
The only command needed to run is the 'make' command. This will build and run the program. After which, it will begin to ask for a word.
To remove the compiled file, use the command: 'make clean'

NOTE:
The Dictionary file must be within the path "files/Dictionary.txt."
The Dictionary file needs to be spelled exactly as such: "Dictionary.txt"