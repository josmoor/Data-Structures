Two files are needed for the program: 'main.cpp' and 'tree.h'

1. Run the command 'make'
    - This will create all the necessary files. After creation, the program will start.
2. Two questions are asked, how many values, then an input of the values.
3. input the amount of numbers that will be converted into a binary tree.
    - Then input each number (in any order).
4. The display of the k-nth lowest value will be displayed upon the last digit put in.