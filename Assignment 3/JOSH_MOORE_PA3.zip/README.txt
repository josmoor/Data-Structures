When the creation of the files are complete, the program will start immediately and ask for a numerical value (the number of queens / size of the board).
NOTE: If you input a value other than a numerical value, the program will cause an error, no exception handling was implemented.

To create all the files, use "Make"
To run the program use "Make exe"
To remove all created files use "Make clean"

'outputData.txt' will contain all the locations of each queen. The FIRST row is the board size (4,4.... 25,25), the rest of the numbers are the queens
locations in decending order by ROW. To see a "graphical" representation of the Queens placement, 'graphicalDisplay.txt' will display the board and queens
according to their respective location.