Makefile commands:
- Make Clean
	** Clears out all unnecessary files
- Make Run
	** Runs the program after all files have been created
- Make
	** Compiles the .CPP and .H files to be ran
	
After compilation and the program is running, only user input is a number. This number generates (N) amount of Rectangles. The program will take the number, generate all the information, write the information in a CSV format file called 'rectData.txt'; The program then exits.

Note: When compiling the files, two 'Warnings' will appear, they can be ignored. They are simply stating that the conversion from INT to FLOAT is to be fixed. This DOES NOT affect the output data.