To run the C++ Program:

1. Run the command 'make'
	- This will create a 'run' file that will be the program.
2. Run the command './run'
	- This will begin the program. It'll ask for inputs of integer values. The maximum array length is 30; to stop before use the value '-1000'.
	- Negative values are allowed 'expect for -1000, which is used for a placeholder to stop the loop sooner.'
3. Once the values have been inputted, the program will display the array unsorted, then sort, then display it sorted in Ascending Order.